# My Seba - Step 5: Login & Register

Frontend authentication UI prototype.

Features:
- Login form
- Register form
- Job Seeker / Service Provider account type
- Password strength indicator
- Confirm password validation
- Show/hide password
- Terms checkbox
- Demo user session using browser localStorage
- Welcome confirmation modal
- Forgot password placeholder
- Responsive design

Files:
- auth.html
- auth.css
- auth.js

Note:
This is NOT production authentication. Passwords are not stored or verified against a secure server. Real authentication, encrypted passwords, email/phone verification, sessions, database and role permissions will be implemented with the backend/database steps.
