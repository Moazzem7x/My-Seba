// Optional helper: running `node database.js` initializes the SQLite database.
require("dotenv").config();
const fs = require("fs");
const Database = require("better-sqlite3");

const db = new Database("myseba.db");
db.pragma("foreign_keys = ON");
db.exec(fs.readFileSync("schema.sql", "utf8"));
console.log("My Seba database initialized: myseba.db");
db.close();
