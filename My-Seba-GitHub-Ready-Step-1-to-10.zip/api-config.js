// After Render deployment, replace this placeholder with your actual backend URL.
// Include this file before page-specific scripts only after wiring each page to the API.
const API_BASE_URL = "https://YOUR-BACKEND.onrender.com";
