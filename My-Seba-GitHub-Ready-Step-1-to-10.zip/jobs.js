const jobs=[
{id:1,title:"Delivery Driver",company:"FastGo Services",location:"Jeddah",category:"Driving",salary:3200,posted:"2 hours ago",type:"Full Time",experience:"1-2 Years",description:"We are looking for a reliable delivery driver to handle customer deliveries safely and on time."},
{id:2,title:"AC Technician",company:"CoolCare Maintenance",location:"Jeddah",category:"Technical",salary:3800,posted:"5 hours ago",type:"Full Time",experience:"3-5 Years",description:"Experienced AC technician needed for residential and commercial maintenance work."},
{id:3,title:"Office Assistant",company:"Modern Business Co.",location:"Riyadh",category:"Office",salary:3500,posted:"1 day ago",type:"Full Time",experience:"1-2 Years",description:"Support daily office operations, documents, calls and basic computer tasks."},
{id:4,title:"Cleaner",company:"Bright Home Services",location:"Makkah",category:"Cleaning",salary:2200,posted:"1 day ago",type:"Full Time",experience:"Fresher",description:"Join our cleaning team for residential and commercial cleaning services."},
{id:5,title:"Graphic Designer",company:"Digital Point",location:"Jeddah",category:"IT & Digital",salary:4500,posted:"2 days ago",type:"Full Time",experience:"3-5 Years",description:"Create social media designs, promotional materials and digital content."},
{id:6,title:"Delivery Coordinator",company:"QuickDrop",location:"Dammam",category:"Delivery",salary:4000,posted:"3 days ago",type:"Full Time",experience:"1-2 Years",description:"Coordinate delivery schedules and communicate with drivers and customers."}
];
let filtered=[...jobs], selectedJob=null;

const grid=document.getElementById("jobsGrid");
function render(){
  const sort=document.getElementById("sort").value;
  let list=[...filtered];
  if(sort==="salary") list.sort((a,b)=>b.salary-a.salary);
  grid.innerHTML=list.length?list.map(j=>`
    <article class="job-card">
      <span class="tag">${j.category}</span>
      <h3>${j.title}</h3><p class="company">${j.company}</p>
      <div class="meta"><span>📍 ${j.location}</span><span>💼 ${j.type}</span><span class="salary">💰 SAR ${j.salary.toLocaleString()}/month</span></div>
      <p class="muted">${j.posted} · ${j.experience}</p>
      <div class="card-actions"><button class="view" onclick="showDetails(${j.id})">View Details</button><button class="apply" onclick="openApply(${j.id})">Apply</button></div>
    </article>`).join(""):`<div class="job-card"><h3>No jobs found</h3><p>Try another keyword, location or category.</p></div>`;
  document.getElementById("resultCount").textContent=`${list.length} job${list.length!==1?"s":""} found`;
}
function searchJobs(){
 const k=document.getElementById("keyword").value.toLowerCase().trim(), l=document.getElementById("location").value.toLowerCase().trim(), c=document.getElementById("category").value;
 filtered=jobs.filter(j=>(!k||(j.title+" "+j.company+" "+j.category).toLowerCase().includes(k))&&(!l||j.location.toLowerCase().includes(l))&&(!c||j.category===c)); render();
}
function showDetails(id){
 selectedJob=jobs.find(j=>j.id===id);
 document.getElementById("detailsContent").innerHTML=`<span class="tag">${selectedJob.category}</span><h2>${selectedJob.title}</h2><p class="company">${selectedJob.company}</p><div class="detail-list"><div>📍 <strong>Location:</strong> ${selectedJob.location}</div><div>💰 <strong>Salary:</strong> SAR ${selectedJob.salary.toLocaleString()}/month</div><div>💼 <strong>Type:</strong> ${selectedJob.type}</div><div>⭐ <strong>Experience:</strong> ${selectedJob.experience}</div><div>🕒 <strong>Posted:</strong> ${selectedJob.posted}</div></div><h3>Job Description</h3><p>${selectedJob.description}</p>`;
 document.getElementById("detailsModal").classList.add("show");
}
function openApply(id){
 selectedJob=jobs.find(j=>j.id===id);
 document.getElementById("applyJobId").value=id;
 document.getElementById("applyJobTitle").textContent=`Applying for: ${selectedJob.title} — ${selectedJob.company}`;
 document.getElementById("applyModal").classList.add("show");
}
document.getElementById("applyFromDetails").onclick=()=>{document.getElementById("detailsModal").classList.remove("show");openApply(selectedJob.id)};
document.getElementById("searchBtn").onclick=searchJobs;
document.getElementById("sort").onchange=render;
document.getElementById("applyForm").addEventListener("submit",e=>{
 e.preventDefault();
 const file=document.getElementById("appCv").files[0];
 if(file && (file.size>5*1024*1024 || !/\.(pdf|doc|docx)$/i.test(file.name))){alert("Please upload PDF/DOC/DOCX file up to 5 MB.");return}
 const ref="MS-JOB-"+Date.now().toString().slice(-7);
 document.getElementById("applyModal").classList.remove("show");
 document.getElementById("reference").textContent=ref;
 document.getElementById("successModal").classList.add("show");
 e.target.reset();
});
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>document.getElementById(b.dataset.close).classList.remove("show"));
document.querySelectorAll(".modal").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)m.classList.remove("show")}));
render();
