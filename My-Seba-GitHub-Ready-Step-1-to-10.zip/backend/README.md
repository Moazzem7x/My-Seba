# My Seba — Step 9
## Database + Secure File Storage

এই ধাপে My Seba-এর frontend-এর জন্য backend foundation তৈরি করা হয়েছে।

### Stack
- Node.js
- Express
- SQLite
- bcrypt password hashing
- JWT authentication
- HTTP-only cookie session
- Helmet security headers
- Rate limiting
- Multer secure upload handling

### Main features
- User registration/login/logout
- User roles: user, provider, admin
- SQLite database
- Jobs
- Job applications
- Services
- CV upload
- CV access control
- Random stored filenames
- PDF/DOC/DOCX validation
- 5 MB default upload limit
- Admin statistics API

### Setup

1. Install Node.js 20+.
2. Open this folder in Terminal.
3. Run:

```bash
npm install
```

4. Copy `.env.example` to `.env`.
5. Set a strong random `JWT_SECRET`.
6. Start:

```bash
npm start
```

API:
`http://localhost:3000`

Health check:
`GET /api/health`

### Important security notes

This is a secure backend foundation, not a complete production deployment.

Before production:
- Use HTTPS.
- Use a strong secret stored outside source control.
- Use a managed database/backups for production.
- Consider cloud object storage for CVs.
- Add antivirus/malware scanning for uploaded documents.
- Add CSRF protection if the authentication architecture requires it.
- Add stronger request validation and audit logs.
- Configure CORS only for trusted frontend origins.
- Add monitoring, backups and recovery procedures.
- Never expose `storage/private` as a public static folder.
- Do not commit `.env` or the SQLite database to Git.

### API overview

Auth:
- POST `/api/auth/register`
- POST `/api/auth/login`
- POST `/api/auth/logout`
- GET `/api/me`

Jobs:
- GET `/api/jobs`
- POST `/api/jobs` (admin)
- POST `/api/jobs/:id/apply` (user)
- GET `/api/applications` (logged-in user)

Services:
- GET `/api/services`
- POST `/api/services` (provider)

CV:
- POST `/api/cv/upload` (user)
- GET `/api/cv` (user)
- GET `/api/cv/:id/download` (owner/admin)

Admin:
- GET `/api/admin/stats`

### Connecting the existing frontend

The existing Step 1–8 pages are frontend prototypes. Their forms can now be connected to these API endpoints.

For browser requests, use:

```js
fetch("http://localhost:3000/api/auth/login", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  credentials: "include",
  body: JSON.stringify({ email, password })
});
```

For CV upload:

```js
const formData = new FormData();
formData.append("cv", file);

fetch("http://localhost:3000/api/cv/upload", {
  method: "POST",
  credentials: "include",
  body: formData
});
```

Do not manually set `Content-Type` for `FormData`.
