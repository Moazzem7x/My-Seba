document.querySelector('.menu-toggle')?.addEventListener('click', () => {
  const nav = document.querySelector('.nav-links');
  nav.style.display = nav.style.display === 'flex' ? '' : 'flex';
  nav.style.position = 'absolute';
  nav.style.top = '64px';
  nav.style.left = '0';
  nav.style.right = '0';
  nav.style.padding = '18px';
  nav.style.background = '#fff';
  nav.style.flexDirection = 'column';
  nav.style.boxShadow = '0 10px 25px rgba(0,0,0,.08)';
});

function searchServices() {
  alert('Search system will be connected in Step 2.');
}
