# My Seba — Step 1

Responsive homepage starter for My Seba.

## Included
- Responsive navigation
- Hero section
- Service categories
- Drop Your CV CTA
- How It Works
- Featured services
- Statistics
- User reviews
- Footer
- Basic mobile menu
- Basic search button placeholder

## Run
Open `index.html` in any modern browser.

## Next
Step 2 will build the real Services page and connect service search/details.
