const users=[
{id:1,name:"Ahmed Ali",email:"ahmed@example.com",role:"Job Seeker",joined:"12 Sep 2026",status:"Active"},
{id:2,name:"Sara Ahmed",email:"sara@example.com",role:"Job Seeker",joined:"10 Sep 2026",status:"Active"},
{id:3,name:"Mohammed Khan",email:"mkhan@example.com",role:"Service Provider",joined:"08 Sep 2026",status:"Active"},
{id:4,name:"Omar Hassan",email:"omar@example.com",role:"Job Seeker",joined:"04 Sep 2026",status:"Suspended"},
{id:5,name:"Bright Home Services",email:"contact@bright.example",role:"Service Provider",joined:"01 Sep 2026",status:"Active"}];
const providers=[
{id:1,name:"CoolCare Maintenance",category:"Repair & Maintenance",location:"Jeddah",rating:"4.9",status:"Pending"},
{id:2,name:"Bright Home Services",category:"Cleaning",location:"Makkah",rating:"4.7",status:"Approved"},
{id:3,name:"Digital Point",category:"Digital Services",location:"Jeddah",rating:"4.8",status:"Approved"},
{id:4,name:"QuickFix Electric",category:"Home Services",location:"Riyadh",rating:"4.6",status:"Pending"}];
const jobs=[
{id:1,title:"Delivery Driver",company:"FastGo Services",location:"Jeddah",apps:28,status:"Active"},
{id:2,title:"AC Technician",company:"CoolCare Maintenance",location:"Jeddah",apps:17,status:"Pending"},
{id:3,title:"Office Assistant",company:"Modern Business Co.",location:"Riyadh",apps:34,status:"Active"},
{id:4,title:"Cleaner",company:"Bright Home Services",location:"Makkah",apps:19,status:"Active"}];
const services=[
["AC Repair","CoolCare Maintenance","Repair & Maintenance",100,"❄️","Pending"],
["Home Cleaning","Bright Home Services","Cleaning",120,"🧹","Approved"],
["Graphic Design","Digital Point","Digital Services",150,"🎨","Approved"],
["Electrical Repair","QuickFix Electric","Home Services",80,"⚡","Pending"],
["Plumbing Service","FixPro","Home Services",90,"🔧","Approved"],
["Delivery Service","QuickDrop","Delivery",50,"🚚","Approved"]];
const applications=[
["Ahmed Ali","Delivery Driver","FastGo Services","Today","Under Review"],
["Sara Ahmed","AC Technician","CoolCare Maintenance","Yesterday","Shortlisted"],
["Omar Hassan","Office Assistant","Modern Business Co.","12 Sep 2026","Rejected"],
["Fahad M.","Cleaner","Bright Home Services","11 Sep 2026","Applied"]];
const reports=[
["User 102","AC Repair service","Incorrect information","Today","Open"],
["User 87","Job: Delivery Driver","Spam / duplicate","Yesterday","Open"],
["User 41","Provider profile","Inappropriate content","10 Sep 2026","Resolved"]];

function showSection(id){document.querySelectorAll(".section").forEach(s=>s.classList.toggle("active",s.id===id));document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.section===id));window.scrollTo(0,0)}
document.querySelectorAll(".nav-item").forEach(b=>b.onclick=()=>showSection(b.dataset.section));
document.getElementById("activity").innerHTML=[
["New provider registration","CoolCare Maintenance submitted a provider profile.","10 minutes ago"],
["New job posting","FastGo Services posted Delivery Driver.","28 minutes ago"],
["New application","A candidate applied for AC Technician.","1 hour ago"],
["Service approved","Home Cleaning was approved for Bright Home Services.","2 hours ago"],
["Report submitted","A service was reported for review.","3 hours ago"]
].map(a=>`<div class="activity"><i class="dot"></i><div><b>${a[0]}</b><small>${a[1]}</small><small>${a[2]}</small></div></div>`).join("");

function renderUsers(){
 const q=(document.getElementById("userSearch").value||"").toLowerCase(),f=document.getElementById("userFilter").value;
 const list=users.filter(u=>(!q||(u.name+" "+u.email).toLowerCase().includes(q))&&(f==="All Users"||u.status===f));
 document.getElementById("usersTable").innerHTML=list.map(u=>`<tr><td><div class="user-cell"><span class="user-avatar">${u.name.split(" ").map(x=>x[0]).slice(0,2).join("")}</span><div><b>${u.name}</b><small>${u.id===5?"Business Provider":"Member"}</small></div></div></td><td>${u.email}</td><td>${u.role}</td><td>${u.joined}</td><td><span class="status ${u.status.toLowerCase()}">${u.status}</span></td><td><button class="action" onclick="toast('User details opened in this demo.')">View</button><button class="action" onclick="toggleUser(${u.id})">${u.status==="Suspended"?"Activate":"Suspend"}</button></td></tr>`).join("")}
function toggleUser(id){const u=users.find(x=>x.id===id);u.status=u.status==="Suspended"?"Active":"Suspended";renderUsers();toast(`User ${u.status.toLowerCase()}.`)}

function renderProviders(){document.getElementById("providersTable").innerHTML=providers.map(p=>`<tr><td><b>${p.name}</b></td><td>${p.category}</td><td>${p.location}</td><td>★ ${p.rating}</td><td><span class="status ${p.status.toLowerCase()}">${p.status}</span></td><td>${p.status==="Pending"?`<button class="action approve" onclick="providerAction(${p.id},'Approved')">Approve</button><button class="action reject" onclick="providerAction(${p.id},'Rejected')">Reject</button>`:`<button class="action" onclick="toast('Provider profile opened.')">View</button>`}</td></tr>`).join("")}
function providerAction(id,status){providers.find(p=>p.id===id).status=status;renderProviders();toast(`Provider ${status.toLowerCase()}.`)}

function renderJobs(){document.getElementById("jobsTable").innerHTML=jobs.map(j=>`<tr><td><b>${j.title}</b></td><td>${j.company}</td><td>${j.location}</td><td>${j.apps}</td><td><span class="status ${j.status.toLowerCase()}">${j.status}</span></td><td>${j.status==="Pending"?`<button class="action approve" onclick="jobAction(${j.id},'Active')">Approve</button><button class="action reject" onclick="jobAction(${j.id},'Rejected')">Reject</button>`:`<button class="action" onclick="toast('Job details opened.')">View</button>`}</td></tr>`).join("")}
function jobAction(id,status){jobs.find(j=>j.id===id).status=status;renderJobs();toast(`Job ${status.toLowerCase()}.`)}

function renderServices(){document.getElementById("servicesGrid").innerHTML=services.map((s,i)=>`<div class="service-card"><div class="icon">${s[4]}</div><h3>${s[0]}</h3><p><b>${s[1]}</b> · ${s[2]}</p><p>Starting from SAR ${s[3]}. Service listing submitted by provider for marketplace review.</p><div class="bottom"><span class="status ${s[5].toLowerCase()}">${s[5]}</span>${s[5]==="Pending"?`<button onclick="serviceAction(${i},'Approved')">Approve</button>`:`<button onclick="toast('Service details opened.')">View</button>`}</div></div>`).join("")}
function serviceAction(i,status){services[i][5]=status;renderServices();toast(`Service ${status.toLowerCase()}.`)}

document.getElementById("applicationsTable").innerHTML=applications.map(a=>`<tr><td><b>${a[0]}</b></td><td>${a[1]}</td><td>${a[2]}</td><td>${a[3]}</td><td><span class="status ${a[4].toLowerCase().replaceAll(" ","")}">${a[4]}</span></td><td><button class="action" onclick="toast('Application details opened.')">View</button></td></tr>`).join("");
document.getElementById("reportsTable").innerHTML=reports.map((r,i)=>`<tr><td>${r[0]}</td><td><b>${r[1]}</b></td><td>${r[2]}</td><td>${r[3]}</td><td><span class="status ${r[4].toLowerCase()}">${r[4]}</span></td><td>${r[4]==="Open"?`<button class="action approve" onclick="resolveReport(${i})">Resolve</button>`:`—`}</td></tr>`).join("");
function resolveReport(i){reports[i][4]="Resolved";document.getElementById("reportsTable").innerHTML=reports.map((r,j)=>`<tr><td>${r[0]}</td><td><b>${r[1]}</b></td><td>${r[2]}</td><td>${r[3]}</td><td><span class="status ${r[4].toLowerCase()}">${r[4]}</span></td><td>${r[4]==="Open"?`<button class="action approve" onclick="resolveReport(${j})">Resolve</button>`:`—`}</td></tr>`).join("");toast("Report resolved.")}
document.getElementById("userSearch").oninput=renderUsers;document.getElementById("userFilter").onchange=renderUsers;
document.getElementById("logout").onclick=()=>{location.href="auth.html"};
function toast(t){const e=document.getElementById("toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),2500)}
renderUsers();renderProviders();renderJobs();renderServices();
