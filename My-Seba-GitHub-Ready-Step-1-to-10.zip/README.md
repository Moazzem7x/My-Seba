# My Seba — GitHub-ready project bundle

This repository package gathers the available Step 1–10 project files into one structure.

## Structure
- Root: static frontend pages/assets for GitHub Pages or Cloudflare Pages
- `backend/`: Node.js + Express + SQLite API from Step 9
- `render.yaml`: Render Blueprint config for the backend
- `docs/step-notes/`: original notes from each frontend step

## Deploy frontend
For GitHub Pages, repository Settings → Pages → deploy from `main` branch / root.
The root `index.html` is the home page.

## Deploy backend
Connect this repository to Render and use `render.yaml`, or create a Web Service with:
- Root directory: `backend`
- Build command: `npm install`
- Start command: `npm start`
- Health check: `/api/health`

Set environment variables:
- `JWT_SECRET`: long random secret
- `FRONTEND_ORIGIN`: exact published frontend origin, e.g. `https://YOUR_USERNAME.github.io`
- `MAX_FILE_SIZE_MB`: `5`
- `UPLOAD_DIR`: `storage/private/cv`
- `NODE_ENV`: `production`

## Security
Never commit `.env`, database files, credentials, or private CVs. This free demo setup uses SQLite and local file storage, which may not persist on free hosting. Do not use it for important real customer CVs until persistent database and private object storage are configured.

## Current integration status
The frontend pages are collected in one root folder and the backend is in `backend/`. This bundle does not guarantee every frontend demo form is already wired to the API. The API base URL must be set after deployment and page-specific forms must be connected and tested.
