# My Seba - Step 7: Service Provider Dashboard

Frontend dashboard for service providers.

Features:
- Provider dashboard overview
- Active services summary
- Add / remove service demo
- Service request management
- Accept / reject pending requests
- Earnings overview
- Monthly earnings visual
- Customer reviews and ratings
- Provider profile editing
- Logout
- Uses the demo user from Step 5 localStorage
- Responsive design

Files:
- provider.html
- provider.css
- provider.js

Important:
This is a frontend prototype. Services, requests, payments, reviews, provider profiles and permissions are not stored in a secure backend database yet. Backend/database integration will be added in later steps.
