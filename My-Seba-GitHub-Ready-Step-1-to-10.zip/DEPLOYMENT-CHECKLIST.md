# Deployment checklist

- [ ] Root `index.html` visible in GitHub
- [ ] All page HTML/CSS/JS files visible
- [ ] `backend/server.js` visible
- [ ] `backend/package.json` visible
- [ ] `render.yaml` visible
- [ ] No `.env` or database files in repository
- [ ] GitHub Pages enabled for root frontend
- [ ] Render backend deployed
- [ ] `JWT_SECRET` set in Render
- [ ] `FRONTEND_ORIGIN` set to exact frontend origin
- [ ] `/api/health` returns `{ "ok": true, ... }`
- [ ] Login/register and all forms tested
- [ ] No real CVs used until persistent private storage is configured
