const requests=[
{id:1,customer:"Ahmed Ali",service:"AC Repair",date:"Today, 4:00 PM",budget:180,status:"Pending"},
{id:2,customer:"Mohammed Khan",service:"Home Cleaning",date:"Tomorrow, 10:00 AM",budget:250,status:"Accepted"},
{id:3,customer:"Sara Ahmed",service:"AC Maintenance",date:"12 Sep 2026",budget:220,status:"Completed"},
{id:4,customer:"Omar Hassan",service:"AC Repair",date:"14 Sep 2026",budget:150,status:"Pending"}];
let services=[
{id:1,name:"AC Repair",category:"Repair & Maintenance",price:100,icon:"❄️",desc:"Professional AC repair and troubleshooting."},
{id:2,name:"Home Cleaning",category:"Cleaning",price:120,icon:"🧹",desc:"Reliable home and apartment cleaning service."},
{id:3,name:"Electrical Repair",category:"Home Services",price:80,icon:"⚡",desc:"Electrical inspection and repair for homes."},
{id:4,name:"Plumbing Service",category:"Home Services",price:90,icon:"🔧",desc:"Fast plumbing repair and maintenance."}];
let currentFilter="All", user=JSON.parse(localStorage.getItem("mySebaUser")||"null")||{name:"Service Provider",role:"Provider"};
const name=user.name||"Service Provider";
document.getElementById("topName").textContent=name;document.getElementById("sideName").textContent=name;document.getElementById("welcomeName").textContent=name.split(" ")[0];document.getElementById("avatar").textContent=name.split(" ").map(x=>x[0]).slice(0,2).join("").toUpperCase();

function showSection(id){document.querySelectorAll(".section").forEach(s=>s.classList.toggle("active",s.id===id));document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.section===id));window.scrollTo(0,0)}
document.querySelectorAll(".nav-item").forEach(b=>b.onclick=()=>showSection(b.dataset.section));

function renderRequests(){const list=currentFilter==="All"?requests:requests.filter(r=>r.status===currentFilter);document.getElementById("requestsTable").innerHTML=list.map(r=>`<tr><td><b>${r.customer}</b></td><td>${r.service}</td><td>${r.date}</td><td>SAR ${r.budget}</td><td><span class="pill ${r.status.toLowerCase()}">${r.status}</span></td><td>${r.status==="Pending"?`<button class="action-btn" onclick="changeRequest(${r.id},'Accepted')">Accept</button><button class="action-btn reject" onclick="changeRequest(${r.id},'Rejected')">Reject</button>`:"—"}</td></tr>`).join("")||`<tr><td colspan="6">No requests found.</td></tr>`;document.getElementById("recentRequests").innerHTML=requests.slice(0,3).map(r=>`<div class="request-row"><div><h3>${r.service}</h3><p>${r.customer} · ${r.date}</p></div><span class="pill ${r.status.toLowerCase()}">${r.status}</span></div>`).join("")}
function changeRequest(id,status){const r=requests.find(x=>x.id===id);r.status=status;renderRequests();toast(`Request ${status.toLowerCase()}.`)}
document.querySelectorAll(".filter").forEach(b=>b.onclick=()=>{document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));b.classList.add("active");currentFilter=b.dataset.filter;renderRequests()});

function renderServices(){document.getElementById("serviceGrid").innerHTML=services.map(s=>`<div class="service-card"><div class="icon">${s.icon}</div><h3>${s.name}</h3><p>${s.category}</p><p>${s.desc}</p><div class="price">From SAR ${s.price}</div><div class="service-actions"><button class="edit" onclick="toast('Service editing will be connected to the backend.')">Edit</button><button class="delete" onclick="removeService(${s.id})">Remove</button></div></div>`).join("")}
function removeService(id){services=services.filter(s=>s.id!==id);renderServices();toast("Service removed from this demo.")}
function openAddService(){document.getElementById("serviceModal").classList.add("show")}
function closeModal(){document.getElementById("serviceModal").classList.remove("show")}
document.getElementById("serviceForm").onsubmit=e=>{e.preventDefault();services.unshift({id:Date.now(),name:serviceName.value,category:serviceCategory.value,price:Number(servicePrice.value),icon:"🛠️",desc:serviceDescription.value||"Professional service from My Seba provider."});renderServices();closeModal();e.target.reset();toast("Service published successfully.")};

document.getElementById("reviewsList").innerHTML=[
["Fahad M.","AC Repair","Excellent service. Arrived on time and fixed the issue quickly.","5.0"],
["Aisha R.","Home Cleaning","Very professional and friendly. The work was neat.","4.8"],
["Yousef K.","Electrical Repair","Good communication and reasonable price.","4.6"]
].map(r=>`<div class="review"><h3>${r[0]} <span class="stars">★★★★★</span></h3><small>${r[1]} · Rating ${r[3]}</small><p>“${r[2]}”</p></div>`).join("");

document.getElementById("profileForm").onsubmit=e=>{e.preventDefault();user.name=businessName.value;user.phone=phone.value;user.email=email.value;user.location=location.value;user.providerCategory=category.value;user.experience=experience.value;user.about=about.value;user.role="Provider";localStorage.setItem("mySebaUser",JSON.stringify(user));document.getElementById("topName").textContent=user.name;document.getElementById("sideName").textContent=user.name;document.getElementById("welcomeName").textContent=user.name.split(" ")[0];toast("Provider profile updated.")};
document.getElementById("logout").onclick=()=>{localStorage.removeItem("mySebaUser");location.href="auth.html"};
function toast(t){const e=document.getElementById("toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),2500)}
renderRequests();renderServices();
