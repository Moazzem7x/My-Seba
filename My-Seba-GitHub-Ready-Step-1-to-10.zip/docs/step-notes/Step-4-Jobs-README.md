# My Seba - Step 4: Jobs

This step adds a responsive Jobs page and a frontend job application flow.

## Included
- Job search by keyword
- Location filter
- Category filter
- Sort by latest or salary
- Job cards and detailed job view
- Apply form
- Optional CV upload (PDF/DOC/DOCX, max 5 MB)
- Application reference number
- Responsive mobile layout

## Files
- jobs.html
- jobs.css
- jobs.js

## Important
This is a frontend prototype. Applications are not stored in a real database yet. Secure database storage, authentication, CV storage, and admin review will be added in later steps.
