const apps=[
{job:"Delivery Driver",company:"FastGo Services",date:"Today",status:"Under Review",ref:"MS-JOB-4283912"},
{job:"AC Technician",company:"CoolCare Maintenance",date:"Yesterday",status:"Shortlisted",ref:"MS-JOB-3918457"},
{job:"Office Assistant",company:"Modern Business Co.",date:"12 Sep 2026",status:"Applied",ref:"MS-JOB-2847163"}];
let user=JSON.parse(localStorage.getItem("mySebaUser")||"null")||{name:"Guest User",phone:"",email:"",role:"User"};
const name=user.name||"Guest User";
document.getElementById("topName").textContent=name;document.getElementById("sideName").textContent=name;document.getElementById("welcomeName").textContent=name.split(" ")[0];
document.getElementById("avatar").textContent=name.split(" ").map(x=>x[0]).slice(0,2).join("").toUpperCase();

function showSection(id){if(id==="jobs"){location.href="jobs.html";return}document.querySelectorAll(".section").forEach(s=>s.classList.toggle("active",s.id===id));document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.section===id));window.scrollTo(0,0)}
document.querySelectorAll(".nav-item").forEach(b=>b.onclick=()=>showSection(b.dataset.section));

function appHTML(a){return `<div class="app-row"><div><h3>${a.job}</h3><p>${a.company} · ${a.date}</p></div><span class="pill ${a.status==="Under Review"?"review":""}">${a.status}</span></div>`}
document.getElementById("recentApps").innerHTML=apps.slice(0,3).map(appHTML).join("");
document.getElementById("applicationsTable").innerHTML=apps.map(a=>`<tr><td><b>${a.job}</b></td><td>${a.company}</td><td>${a.date}</td><td><span class="pill ${a.status==="Under Review"?"review":""}">${a.status}</span></td><td>${a.ref}</td></tr>`).join("");

document.getElementById("profileName").value=user.name||"";
document.getElementById("profilePhone").value=user.phone||"";
document.getElementById("profileEmail").value=user.email||"";
document.getElementById("profileForm").onsubmit=e=>{e.preventDefault();user.name=document.getElementById("profileName").value;user.phone=document.getElementById("profilePhone").value;user.email=document.getElementById("profileEmail").value;user.location=document.getElementById("profileLocation").value;user.category=document.getElementById("profileCategory").value;user.experience=document.getElementById("profileExperience").value;user.about=document.getElementById("profileAbout").value;localStorage.setItem("mySebaUser",JSON.stringify(user));document.getElementById("topName").textContent=user.name;document.getElementById("sideName").textContent=user.name;document.getElementById("welcomeName").textContent=user.name.split(" ")[0];toast("Profile updated successfully")};
document.getElementById("replaceCv").onclick=()=>toast("CV replacement will connect to secure file storage in the backend step.");
document.getElementById("logout").onclick=()=>{localStorage.removeItem("mySebaUser");location.href="auth.html"};
function toast(t){const el=document.getElementById("toast");el.textContent=t;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2500)}
