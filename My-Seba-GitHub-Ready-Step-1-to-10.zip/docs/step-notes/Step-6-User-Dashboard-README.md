# My Seba - Step 6: User Dashboard

Frontend dashboard for registered job seekers.

Features:
- Dashboard overview and account summary
- Recent job applications
- Application status tracking
- My Applications table
- My CV section
- CV status and replacement placeholder
- Editable profile
- Saved Jobs section
- Logout
- Uses the demo user created in Step 5 via localStorage
- Responsive desktop/tablet/mobile layout

Files:
- dashboard.html
- dashboard.css
- dashboard.js

Important:
This is a frontend prototype. Application records, CV files, profile data, authentication sessions and saved jobs are not yet stored in a secure server database. Those will be connected during the backend/database steps.
