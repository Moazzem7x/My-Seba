# My Seba — Step 2: Services
Open `services.html` in a browser.
Includes category filtering, keyword search, location filter, sorting, responsive service cards, and provider CTA.
Next: Step 3 — Drop Your CV upload system.
