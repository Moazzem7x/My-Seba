require("dotenv").config();

const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const cookieParser = require("cookie-parser");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const Database = require("better-sqlite3");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "dev-only-change-me";
const MAX_FILE_SIZE = Number(process.env.MAX_FILE_SIZE_MB || 5) * 1024 * 1024;
const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || "storage/private/cv");

if (JWT_SECRET === "dev-only-change-me") {
  console.warn("WARNING: Set a strong JWT_SECRET in .env before production.");
}

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const db = new Database("myseba.db");
db.pragma("foreign_keys = ON");
db.exec(fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8"));

app.use(helmet());
const allowedFrontendOrigin = process.env.FRONTEND_ORIGIN || "http://localhost:5500";
app.use(cors({
  origin: allowedFrontendOrigin,
  credentials: true
}));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false
});

function signToken(user) {
  return jwt.sign(
    { id: user.id, role: user.role, email: user.email },
    JWT_SECRET,
    { expiresIn: "2h" }
  );
}

function authRequired(req, res, next) {
  try {
    const token = req.cookies.myseba_token ||
      (req.headers.authorization || "").replace(/^Bearer\s+/i, "");

    if (!token) return res.status(401).json({ error: "Authentication required" });

    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: "Invalid or expired session" });
  }
}

function roleRequired(...roles) {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: "Access denied" });
    }
    next();
  };
}

function publicUser(user) {
  return {
    id: user.id,
    full_name: user.full_name,
    email: user.email,
    mobile: user.mobile,
    role: user.role,
    status: user.status,
    created_at: user.created_at
  };
}

app.get("/api/health", (req, res) => {
  res.json({ ok: true, service: "My Seba API", time: new Date().toISOString() });
});

app.post("/api/auth/register", authLimiter, async (req, res) => {
  const { full_name, email, mobile, password, role = "user" } = req.body;

  if (!full_name || !email || !password) {
    return res.status(400).json({ error: "Full name, email and password are required" });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: "Password must be at least 8 characters" });
  }
  if (!["user", "provider"].includes(role)) {
    return res.status(400).json({ error: "Invalid role" });
  }

  try {
    const password_hash = await bcrypt.hash(password, 12);
    const result = db.prepare(`
      INSERT INTO users (full_name, email, mobile, password_hash, role)
      VALUES (?, ?, ?, ?, ?)
    `).run(full_name.trim(), email.trim().toLowerCase(), mobile || null, password_hash, role);

    const user = db.prepare("SELECT * FROM users WHERE id = ?").get(result.lastInsertRowid);
    res.status(201).json({ user: publicUser(user) });
  } catch (err) {
    if (String(err.message).includes("UNIQUE")) {
      return res.status(409).json({ error: "Email already registered" });
    }
    res.status(500).json({ error: "Registration failed" });
  }
});

app.post("/api/auth/login", authLimiter, async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required" });
  }

  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email.trim().toLowerCase());
  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json({ error: "Invalid email or password" });
  }
  if (user.status !== "active") {
    return res.status(403).json({ error: "Account is suspended" });
  }

  const token = signToken(user);
  res.cookie("myseba_token", token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 2 * 60 * 60 * 1000
  });

  res.json({ user: publicUser(user) });
});

app.post("/api/auth/logout", (req, res) => {
  res.clearCookie("myseba_token");
  res.json({ message: "Logged out" });
});

app.get("/api/me", authRequired, (req, res) => {
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.user.id);
  if (!user) return res.status(404).json({ error: "User not found" });
  res.json({ user: publicUser(user) });
});

app.get("/api/jobs", (req, res) => {
  const jobs = db.prepare(`
    SELECT id, title, company, location, category, description, salary, status, created_at
    FROM jobs
    WHERE status = 'approved'
    ORDER BY id DESC
  `).all();
  res.json({ jobs });
});

app.post("/api/jobs", authRequired, roleRequired("admin"), (req, res) => {
  const { title, company, location, category, description, salary } = req.body;
  if (!title) return res.status(400).json({ error: "Job title is required" });

  const result = db.prepare(`
    INSERT INTO jobs (title, company, location, category, description, salary)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(title, company || null, location || null, category || null, description || null, salary || null);

  res.status(201).json({ id: result.lastInsertRowid, message: "Job created for moderation" });
});

app.post("/api/jobs/:id/apply", authRequired, roleRequired("user"), (req, res) => {
  const job = db.prepare("SELECT id FROM jobs WHERE id = ? AND status = 'approved'").get(req.params.id);
  if (!job) return res.status(404).json({ error: "Job not found" });

  try {
    const result = db.prepare(`
      INSERT INTO applications (job_id, user_id) VALUES (?, ?)
    `).run(job.id, req.user.id);
    res.status(201).json({ application_id: result.lastInsertRowid, status: "submitted" });
  } catch (err) {
    if (String(err.message).includes("UNIQUE")) {
      return res.status(409).json({ error: "You already applied for this job" });
    }
    res.status(500).json({ error: "Application failed" });
  }
});

app.get("/api/applications", authRequired, (req, res) => {
  const applications = db.prepare(`
    SELECT a.id, a.job_id, j.title, j.company, a.status, a.applied_at
    FROM applications a
    JOIN jobs j ON j.id = a.job_id
    WHERE a.user_id = ?
    ORDER BY a.id DESC
  `).all(req.user.id);
  res.json({ applications });
});

app.post("/api/services", authRequired, roleRequired("provider"), (req, res) => {
  const { title, category, description, location, price } = req.body;
  if (!title || !category) {
    return res.status(400).json({ error: "Title and category are required" });
  }

  const result = db.prepare(`
    INSERT INTO services
      (provider_id, title, category, description, location, price)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(
    req.user.id, title, category, description || null,
    location || null, Number(price || 0)
  );

  res.status(201).json({ service_id: result.lastInsertRowid, status: "pending" });
});

app.get("/api/services", (req, res) => {
  const services = db.prepare(`
    SELECT s.id, s.title, s.category, s.description, s.location, s.price,
           s.rating, s.status, u.full_name AS provider_name
    FROM services s
    JOIN users u ON u.id = s.provider_id
    WHERE s.status = 'approved'
    ORDER BY s.id DESC
  `).all();
  res.json({ services });
});

const allowedMime = new Set([
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
]);

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, UPLOAD_DIR),
    filename: (req, file, cb) => {
      const safeName = `${crypto.randomUUID()}${path.extname(file.originalname).toLowerCase()}`;
      cb(null, safeName);
    }
  }),
  limits: { fileSize: MAX_FILE_SIZE, files: 1 },
  fileFilter: (req, file, cb) => {
    if (!allowedMime.has(file.mimetype)) {
      return cb(new Error("Only PDF, DOC and DOCX files are allowed"));
    }
    cb(null, true);
  }
});

app.post("/api/cv/upload", authRequired, roleRequired("user"), (req, res) => {
  upload.single("cv")(req, res, (err) => {
    if (err) {
      return res.status(400).json({ error: err.message || "File upload failed" });
    }
    if (!req.file) return res.status(400).json({ error: "CV file is required" });

    const relativePath = path.relative(process.cwd(), req.file.path).replaceAll("\\", "/");

    const result = db.prepare(`
      INSERT INTO cv_files
        (user_id, original_name, stored_name, mime_type, size_bytes, path)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(
      req.user.id,
      req.file.originalname,
      req.file.filename,
      req.file.mimetype,
      req.file.size,
      relativePath
    );

    res.status(201).json({
      cv_id: result.lastInsertRowid,
      file_name: req.file.originalname,
      size_bytes: req.file.size,
      message: "CV uploaded securely"
    });
  });
});

app.get("/api/cv", authRequired, roleRequired("user"), (req, res) => {
  const files = db.prepare(`
    SELECT id, original_name, mime_type, size_bytes, uploaded_at
    FROM cv_files
    WHERE user_id = ?
    ORDER BY id DESC
  `).all(req.user.id);
  res.json({ files });
});

app.get("/api/cv/:id/download", authRequired, (req, res) => {
  const cv = db.prepare(`
    SELECT * FROM cv_files WHERE id = ?
  `).get(req.params.id);

  if (!cv) return res.status(404).json({ error: "CV not found" });
  if (cv.user_id !== req.user.id && req.user.role !== "admin") {
    return res.status(403).json({ error: "Access denied" });
  }

  const absolutePath = path.resolve(cv.path);
  if (!absolutePath.startsWith(UPLOAD_DIR + path.sep)) {
    return res.status(400).json({ error: "Invalid file path" });
  }
  if (!fs.existsSync(absolutePath)) {
    return res.status(404).json({ error: "Stored file not found" });
  }

  res.download(absolutePath, cv.original_name);
});

app.get("/api/admin/stats", authRequired, roleRequired("admin"), (req, res) => {
  const count = table => db.prepare(`SELECT COUNT(*) AS total FROM ${table}`).get().total;
  res.json({
    users: count("users"),
    providers: db.prepare("SELECT COUNT(*) AS total FROM users WHERE role='provider'").get().total,
    jobs: count("jobs"),
    services: count("services"),
    applications: count("applications"),
    cvs: count("cv_files")
  });
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

app.listen(PORT, () => {
  console.log(`My Seba API running at http://localhost:${PORT}`);
});