# My Seba — Step 3: Drop Your CV
Frontend CV submission page.
Included:
- Candidate information form
- Job category and experience
- PDF/DOC/DOCX validation
- 5 MB size limit
- Drag & drop / browse upload
- Submission confirmation and reference number
- Application status timeline
- Responsive design

Important: this is the frontend prototype. Real secure file storage and database will be connected in later backend steps.
Next: Step 4 — Jobs page and job application flow.
